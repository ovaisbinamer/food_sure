"""
model_utils.py — Food-Sure inference layer.

Loads the models exported by notebook Cell 13 (web_models/<spice>/model.keras
+ label_map.json, plus web_models/manifest.json) and exposes
predict_adulteration(), the one function the FastAPI app (and any future
Flask/Streamlit frontend) calls.

Confirmed against the real notebook (Cell 13's web-export + Cell 14's
predict_adulteration()) as of the 2026-08-16 training run, where ResNet50
won all three spices:
  1. web_models/<spice>/ always contains exactly 'model.keras' and
     'label_map.json' (fixed filenames — not stored in the manifest).
  2. Class labels are '{pct}_pct_{adulterant}', e.g. '10_pct_sawdust',
     '5_pct_millet', plus the literal 'pure'.
  3. manifest.json's "preprocess" field is one of 'rescale' (Custom CNN),
     'mobilenet_v2', or 'resnet50' — matching tf.keras.applications'
     preprocess_input for the winning model, or raw /255 rescale for the CNN.
"""

import os
import json
import re
import numpy as np
from PIL import Image, ImageOps
import tensorflow as tf

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Point this at wherever you copied web_models/ locally after downloading
# it from Google Drive. Override with the WEB_MODELS_DIR env var if needed.
WEB_MODELS_DIR = os.environ.get(
    "WEB_MODELS_DIR", os.path.join(BASE_DIR, "web_models")
)

SEVERITY_MAP = {
    "pure": "PURE",
    "5": "LOW",
    "10": "MEDIUM",
    "15": "HIGH",
}

# Each spice model is a closed 7-class classifier (pure + 2 adulterants x 3
# concentrations) trained ONLY on that spice. Nothing in the pipeline checks
# that the uploaded photo actually matches the spice the user selected in the
# UI -- if it doesn't, the model still forces the image into whichever of its
# 7 known classes looks closest, and returns a confident-looking but
# meaningless result (e.g. a red chilli photo run against the turmeric model
# coming back as "5% semolina", a turmeric-only adulterant). A low top-1
# confidence is the best cheap signal we have that this may have happened --
# it's a proxy, not real out-of-distribution detection, but it catches the
# common case of wrong-spice-selected or an unclear photo. Override with the
# LOW_CONFIDENCE_THRESHOLD env var if needed.
LOW_CONFIDENCE_THRESHOLD = float(os.environ.get("LOW_CONFIDENCE_THRESHOLD", "0.45"))

_manifest = None
_models = {}       # spice -> tf.keras.Model
_label_maps = {}   # spice -> {index(str): class_name}


def _load_manifest():
    global _manifest
    if _manifest is None:
        manifest_path = os.path.join(WEB_MODELS_DIR, "manifest.json")
        if not os.path.exists(manifest_path):
            raise FileNotFoundError(
                f"manifest.json not found at {manifest_path}. "
                f"Run Cell 13 in the notebook and copy web_models/ here first."
            )
        with open(manifest_path) as f:
            _manifest = json.load(f)
    return _manifest


def get_available_spices():
    return list(_load_manifest().keys())


def _get_model(spice):
    manifest = _load_manifest()
    if spice not in manifest:
        raise ValueError(f"Unknown spice '{spice}'. Available: {list(manifest.keys())}")

    if spice not in _models:
        entry = manifest[spice]
        # Cell 13 always writes these two fixed filenames per spice folder —
        # the manifest itself doesn't carry a model_file/label_map_file key.
        model_path = os.path.join(WEB_MODELS_DIR, spice, "model.keras")
        label_path = os.path.join(WEB_MODELS_DIR, spice, "label_map.json")

        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model file missing: {model_path}")

        _models[spice] = tf.keras.models.load_model(model_path)
        with open(label_path) as f:
            _label_maps[spice] = json.load(f)

    return _models[spice], _label_maps[spice], manifest[spice]


def parse_severity(class_name: str):
    """
    Turns a class label like '10_pct_charcoal' into (adulterant, severity, pct).
    'pure' -> ('none', 'PURE', 0).

    Real label format confirmed from the notebook (Cell 8/9 generator classes
    and Cell 14's class_to_severity()): '{pct}_pct_{adulterant}', e.g.
    '5_pct_millet', '10_pct_sawdust', '15_pct_rice_flour'. Severity is decided
    by substring/pct match, mirroring the notebook's own logic exactly.
    """
    name = class_name.strip().lower()
    if name == "pure":
        return "none", "PURE", 0

    match = re.match(r"^(\d+)_pct_(.+)$", name)
    if match:
        pct, adulterant = match.group(1), match.group(2)
        severity = SEVERITY_MAP.get(pct, "UNKNOWN")
        return adulterant, severity, int(pct)

    return "unknown", "UNKNOWN", None


def _preprocess_image(pil_img: Image.Image, img_size: int, preprocess: str):
    """
    IMPORTANT: for 'mobilenet_v2' and 'resnet50', do NOT call keras.applications'
    preprocess_input here. Cell 8/9's build_mobilenetv2()/build_resnet50() bake
    preprocessing into the model graph itself as the very first layer
    (`x = mobilenet_preprocess(inputs)` / `x = resnet_preprocess(inputs)`, right
    after the Input layer, before the frozen base model). The notebook's own
    Cell 7 comment confirms this deliberately: "plain_datagen_tl = ImageDataGenerator()
    # no preprocessing — model handles it" and warns that applying preprocess_input
    a second time outside the model "would double-process the pixel values and
    hurt accuracy." Verified empirically: applying preprocess_input here dropped
    validation accuracy from ~75% (matching the real test_acc) to ~19% on a
    21-image spot-check across all three spices — this was a real, serious bug,
    not just theoretical. So for those two tags we only resize/float-cast and
    hand the model raw [0,255] pixels; the model does the rest internally.
    Only 'rescale' (Custom CNN, which has no internal preprocessing layer)
    needs the external /255 scaling done here.
    """
    # Phone cameras commonly store an EXIF orientation tag instead of
    # physically rotating pixels. PIL ignores that tag by default, so a
    # portrait photo can get fed in sideways/upside-down at inference time
    # even though every training image (loaded via the dataset pipeline,
    # which strips this) was upright. This alone can tank real-world demo
    # accuracy on phone-shot samples even though the model is fine.
    pil_img = ImageOps.exif_transpose(pil_img)
    pil_img = pil_img.convert("RGB").resize((img_size, img_size))
    arr = np.array(pil_img).astype("float32")
    x = np.expand_dims(arr, axis=0)

    if preprocess == "rescale":
        x = x / 255.0
    elif preprocess in ("mobilenet_v2", "resnet50"):
        pass  # model's own input layer applies the matching preprocess_input
    else:
        raise ValueError(f"Unknown preprocess type: {preprocess}")

    return x


def predict_adulteration(image, spice: str) -> dict:
    """
    image: file path (str), bytes, or PIL.Image
    spice: one of get_available_spices()

    Returns:
      {
        "spice": "black_pepper_powder",
        "predicted_class": "charcoal_10",
        "confidence": 0.87,
        "adulterant": "charcoal",
        "severity": "MEDIUM",
        "concentration_pct": 10,
        "severity_message": "...",
        "model_used": "MobileNetV2",
        "top3": [["charcoal_10", 0.87], ["charcoal_5", 0.09], ["pure", 0.02]]
      }
    """
    model, label_map, entry = _get_model(spice)

    if isinstance(image, (str, bytes, os.PathLike)) and not isinstance(image, bytes):
        pil_img = Image.open(image)
    elif isinstance(image, bytes):
        import io
        pil_img = Image.open(io.BytesIO(image))
    elif isinstance(image, Image.Image):
        pil_img = image
    else:
        raise TypeError("image must be a file path, bytes, or PIL.Image")

    x = _preprocess_image(pil_img, entry["img_size"], entry["preprocess"])
    preds = model.predict(x, verbose=0)[0]  # shape (num_classes,)

    order = np.argsort(preds)[::-1]
    top_idx = int(order[0])
    predicted_class = label_map[str(top_idx)]
    confidence = float(preds[top_idx])

    adulterant, severity, pct = parse_severity(predicted_class)

    severity_messages = {
        "PURE": f"Sample appears pure {spice.replace('_', ' ')}.",
        "LOW": f"Low-level adulteration detected ({adulterant}, ~5%).",
        "MEDIUM": f"Moderate adulteration detected ({adulterant}, ~10%).",
        "HIGH": f"High adulteration detected ({adulterant}, ~15%).",
        "UNKNOWN": "Could not determine severity from model output.",
    }

    top3 = [
        [label_map[str(int(i))], float(preds[int(i)])]
        for i in order[:3]
    ]

    low_confidence = confidence < LOW_CONFIDENCE_THRESHOLD
    warning = (
        f"This result has unusually low confidence ({confidence * 100:.0f}%). "
        f"Double-check that this photo is really {spice.replace('_', ' ')} -- "
        "each model only recognizes its own spice and will still return an "
        "answer even on a mismatched or unclear photo. Try a clearer, "
        "well-lit shot, or confirm you selected the right spice above."
        if low_confidence
        else None
    )

    return {
        "spice": spice,
        "predicted_class": predicted_class,
        "confidence": round(confidence, 4),
        "adulterant": adulterant,
        "severity": severity,
        "concentration_pct": pct,
        "severity_message": severity_messages.get(severity, severity_messages["UNKNOWN"]),
        "model_used": entry["model_name"],
        "top3": top3,
        "low_confidence": low_confidence,
        "warning": warning,
    }
